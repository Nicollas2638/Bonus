package Principal;

import java.math.BigDecimal;
import java.util.*;

public class ControleBonus {

    public static int aplicarBonus(List<Funcionario> funcionarios, List<Departamento> departamentos) {
        try {
            BigDecimal maxVendas = BigDecimal.ZERO;
            for (Departamento dep : departamentos) {
                if (dep.getVendas().compareTo(maxVendas) > 0) {
                    maxVendas = dep.getVendas();
                }
            }

            Set<Integer> departamentosTop = new HashSet<>();
            for (Departamento dep : departamentos) {
                if (dep.getVendas().compareTo(maxVendas) == 0) {
                    departamentosTop.add(dep.getId());
                }
            }

            boolean algumFuncionarioElegivel = false;
            for (Funcionario func : funcionarios) {
                if (departamentosTop.contains(func.getCodigoDepartamento())) {
                    algumFuncionarioElegivel = true;
                    BigDecimal bonus = func.calcularBonus();
                    func.setSalario(func.getSalario().add(bonus));
                }
            }
        }
            return 0;

    }
}
