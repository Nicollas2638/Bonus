package Principal;

import java.math.BigDecimal;

public class Departamento {
    private int id;
    private BigDecimal vendas;
    private String telefone;
    private String email;

    public Departamento(int id, BigDecimal vendas, String telefone, String email) {
        this.id = id;
        this.vendas = vendas;
        this.telefone = telefone;
        this.email = email;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public BigDecimal getVendas() {
        return vendas;
    }

    public void setVendas(BigDecimal vendas) {
        this.vendas = vendas;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    @Override
    public String toString() {
        return "Departamento{" +
                "id=" + id +
                ", vendas=" + vendas +
                ", telefone='" + telefone + '\'' +
                ", email='" + email + '\'' +
                '}';
    }
}

