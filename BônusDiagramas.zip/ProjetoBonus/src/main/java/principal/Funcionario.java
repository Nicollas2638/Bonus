package Principal;

import java.math.BigDecimal;

public abstract class Funcionario {
    private int id;
    private BigDecimal salario;
    private String cargo;
    private int codigoDepartamento;

    public Funcionario(int id, BigDecimal salario, String cargo, int codigoDepartamento) {
        this.id = id;
        this.salario = salario;
        this.cargo = cargo;
        this.codigoDepartamento = codigoDepartamento;
    }

    public int getId() {
        return id;
    }

    public BigDecimal getSalario() {
        return salario;
    }

    public void setSalario(BigDecimal salario) {
        this.salario = salario;
    }

    public String getCargo() {
        return cargo;
    }

    public int getCodigoDepartamento() {
        return codigoDepartamento;
    }

    public BigDecimal calcularBonus() {
        BigDecimal limiteSalario = new BigDecimal("150000");
        if (salario.compareTo(limiteSalario) >= 0 || "Gerente".equalsIgnoreCase(cargo)) {
            return new BigDecimal("1000");
        }
        return new BigDecimal("2000");
    }
}
