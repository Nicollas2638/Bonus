package Principal;

import java.math.BigDecimal;

class Gerente extends Funcionario {
    public Gerente(int id, BigDecimal salario, int codigoDepartamento) {
        super(id, salario, "Gerente", codigoDepartamento);
    }

    @Override
    public BigDecimal calcularBonus() {
        return new BigDecimal("1000");
    }
}

