package Principal;

import java.math.BigDecimal;
import java.util.*;

public class Bonus {
    public static void main(String[] args) {
        List<Funcionario> funcionarios = Arrays.asList(
            new Vendedor(1,("170000"), 1),
            new Gerente(2, ("120000"), 2),
            new Vendedor(3,("160000"), 3)
        );

        List<Departamento> departamentos = Arrays.asList(
            new Departamento(1, ("500000"),
            new Departamento(2,"600000"),
        );

        int resultado = ControleBonus.aplicarBonus(funcionarios, departamentos);
        if (resultado == 0) {
            System.out.println("Bônus liberado!");
        } else if (resultado == 1) {
            System.out.println("Erro: Uma ou mais tabelas estão vazias.");
        } else if (resultado == 2) {
            System.out.println("Erro: Nenhum funcionário elegível.");
        }

        for (Funcionario func : funcionarios) {
            System.out.println("Funcionario ID: " + func.getId() + ", Novo Salario: " + func.getSalario());
        }
    }
}
